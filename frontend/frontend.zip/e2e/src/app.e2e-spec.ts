import { UltimaPage } from './app.po';

describe('ultima App', function() {
  let page: UltimaPage;

  beforeEach(() => {
    page = new UltimaPage();
  });

});
