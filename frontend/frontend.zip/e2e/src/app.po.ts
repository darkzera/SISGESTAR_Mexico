import { browser, element, by } from 'protractor';

export class UltimaPage {
  navigateTo() {
    return browser.get('/');
  }
}
