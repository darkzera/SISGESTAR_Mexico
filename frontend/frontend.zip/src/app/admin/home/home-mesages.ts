export class HomeMesages {
    public static RESPONSAVEL_DATA_NASCIMENTO = 'Data de Nascimento';
    public static RESPONSAVEL_NOME = 'Nome';
    public static RESPONSAVEL_EMAIL = 'email';
    public static RESPONSAVEL_SAVE_SUCESS = 'Reponsavel criado com sucesso!';
}
