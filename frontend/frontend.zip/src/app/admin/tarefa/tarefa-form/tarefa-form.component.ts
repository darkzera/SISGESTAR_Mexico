import { Component, OnInit, ViewChild } from '@angular/core';
import { BlockUI, NgBlockUI } from 'ng-block-ui';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ConfirmationService } from 'primeng/api';
import { ActivatedRoute, Router } from '@angular/router';
import { PageNotificationService } from '@nuvem/primeng-components';
import { finalize } from 'rxjs/operators';
import { TarefaModel } from 'src/app/shared-models/tarefa-model';
import { GenericTableColumn } from 'src/app/shared/models/generic-table-column';
import { GenericTableComponent } from 'src/app/components/generic-table/generic-table.component';
import { GenericTableButton } from 'src/app/shared/models/generic-table-button';

import { TarefaUtil } from "../tarefa-util";
import { TarefaService } from 'src/app/shared-services/tarefa-service';
import { Page } from 'src/app/utils/page';
import { GenericTableUpdateEvent } from 'src/app/shared/models/generic-table-update-event';

@Component({
    selector: 'app-home',
    templateUrl: './tarefa-form.component.html',
    styleUrls: ['tarefa-form.component.scss']
})
export class TarefaFormComponent implements OnInit {
    

    // MSG = UserMesages;
    isSubmited = false;
    @BlockUI() blockUI: NgBlockUI;

    title = '*** tarefatarefa';
    // tarefa = 'tarefa'

    SERVICE = this.tarefaService;

    tarefas: TarefaModel[] = [];
    COLUMNS: GenericTableColumn[] = TarefaUtil.COLUMNS;
    @ViewChild(GenericTableComponent) tarefa: GenericTableComponent;
    BUTTONS: GenericTableButton<TarefaModel>[] = [
        {
            icon: 'edit',
            description: 'editar',
            action: row => this.editUser(row.id)
        },
        {
            icon: 'delete',
            description: 'deletar',
            action: row => this.confirmacaoDeletar(row.id)
        },
        {
            icon: 'more',
            description: '+',
            action: row => this.fetchDetails(row.id)
        },
        {
            icon: 'view',
            description: '+',
            action: row => this.confirmacaoDeletar(row.id)
        },
    ];


    constructor(
        protected confirmationService: ConfirmationService,
        protected pageNotificationService: PageNotificationService,
        protected route: ActivatedRoute,
        protected router: Router,
        private tarefaService: TarefaService,
    ) {
    }

    ngOnInit() {
        this.loadTable();
    }

    loadTable() {
        this.blockUI.start();
        this.tarefaService.findAllWithPages()
            .pipe(finalize(() => this.blockUI.stop()))
            .subscribe(tarefas => this.tarefa.result = tarefas);
    }

    obterPorId(id: number) {
        this.blockUI.start();
    }

    fetchDetails(id: number): void {
        throw new Error('Method not implemented.');
    }
    confirmacaoDeletar(id: number): void {
        throw new Error('Method not implemented.');
    }
    editUser(id: number): void {
        // Modal de visualizar + info da tarefa
        throw new Error('Method not implemented.');
    }

    updateTable(event: GenericTableUpdateEvent) {
        this.tarefa.table = event.table;
    }
}
