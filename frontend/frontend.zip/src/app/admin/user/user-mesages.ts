export class UserMesages {
    public static USUARIO_NOME = 'Nome';
    public static USUARIO_EMAIL = 'Email';
    public static USUARIO_SAVE_SUCESS = 'Usuario criado com sucesso!';
}
