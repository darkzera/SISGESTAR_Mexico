export class ComentariosListModel {
    constructor(
    public id?: number,
    public descricao?: string, 
    public data_comentario?: string,
    public idUsuario?: number, 
    ){}
}