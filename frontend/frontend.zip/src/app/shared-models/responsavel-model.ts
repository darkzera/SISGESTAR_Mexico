export class ResponsavelModel {
    constructor(
    public id?: number,
    public nome?: string,
    public dataNascimento?: string,
    public email?: string,
    public status?: boolean
    ) {
    }
}
