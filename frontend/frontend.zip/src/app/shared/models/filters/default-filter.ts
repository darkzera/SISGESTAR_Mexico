export class DefaultFilter {
    query?: string;
    status?: boolean;
}
