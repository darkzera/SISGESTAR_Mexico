export class GenericTableFilter {
    field: string;
    type: string;
    label: string;
}
