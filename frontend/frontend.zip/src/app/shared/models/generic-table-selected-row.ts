export class GenericTableSelectedRow {
        public data?;
        public control?;
}
