export class MessageUtil {
    public static LABELS_FILTER = 'filtro';
    public static BUTTON_EXPORT_CSV = 'exportar';
    public static RECORD_NOT_FOUND = 'nada encontrado';
    public static TOTAL_RECORDS = 'total';
    public static PREVIOUS = 'anterior';
    public static NEXT = 'proximo';
    public static NEW = 'Cadastra novo';
    public static LOADING_SCREEN = 'Carregando ...';
    public static REQUIRED_FIELDS = 'Campos obrigatorio não preenchidos';

}
